<?php

return [
  'locales' => ['en', 'ar']
];
