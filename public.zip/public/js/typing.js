// This function is for typing text effects

var typed = new Typed("#typed", {
  stringsElement: '#typed-strings',
  typeSpeed: 100,
  backSpeed: 100,
  loop: true,
});

// This code is to test the home video background

const video = document.querySelector("video");
video.play(); 