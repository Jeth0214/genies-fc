<?php

return [

  /*
    |--------------------------------------------------------------------------
    | Translations use globally - en
    |--------------------------------------------------------------------------
    */

  // Be a part of our growing team !!
  'be-part-title' =>  'Be a part of our growing team!!',


  // buttons 
  'register-btn' => 'Register Now!',
  'contact-btn' => 'Contact Us!',
  'company-name' => 'Genies FC',

];
