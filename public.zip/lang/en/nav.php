<?php

return [

  /*
    |--------------------------------------------------------------------------
    | Navigations Lines
    |--------------------------------------------------------------------------
    */

  'home' => 'Home',
  'about-us' => 'About-us',
  'tomoh' => 'Genies FC',
  'events' => 'Events',
  'news' => 'News',
  'facilities' => 'Facilities',
  'syllabus' => 'Syllabus',
  'live-streams' => 'Live Streams',
  'terms-and-policy' => 'Terms and Policies',
  'contact-us' => 'Contact Us',
  'registration' => 'Register Now',
];
