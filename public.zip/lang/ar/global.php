<?php

return [

  /*
    |--------------------------------------------------------------------------
    | Translations use globally - arabic
    |--------------------------------------------------------------------------
    */


  // Be a part of our growing team !!
  'be-part-title' =>  '!!' . 'كن جزءا من فريقنا ',


  // buttons 
  'register-btn' => 'سجل الآن',
  'contact-btn' => 'اتصل بنا',

  'company-name' => 'طموح الاحتراف',
];
