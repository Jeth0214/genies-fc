// This function is for typing text effects
import Typed from 'typed.js';

var typed = new Typed("#auto-type", {
  strings: ["Analyzing.", "Development.", "Deployment."],
  typeSpeed: 100,
  backSpeed: 100,
  loop: true,
});