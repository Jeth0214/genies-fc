import './bootstrap';

import './register/register';
import './contact-us/contact-us';
import './typing';
